import { useEffect } from "react";
import { Toaster } from "sonner";
import { CardMount } from "@/components/card-mount";
import { HelpOverlay } from "@/components/help-overlay";
import { CameraView } from "@/components/views/camera-view";
import { HomeView } from "@/components/views/home-view";
import { ResultView } from "@/components/views/result-view";
import { WorkspaceView } from "@/components/views/workspace-view";
import { bootStereo, useStereo } from "@/store/stereo";

export function StereoApp() {
  const view = useStereo((s) => s.view);

  useEffect(() => bootStereo(), []);

  if (view === "camera") {
    return (
      <>
        <CameraView />
        <Toaster
          theme="dark"
          position="top-center"
          toastOptions={{ className: "bg-surface text-fg border-border-strong" }}
        />
      </>
    );
  }

  return (
    <CardMount home={view === "home"}>
      {view === "home" ? <HomeView /> : null}
      {view === "workspace" ? <WorkspaceView /> : null}
      {view === "result" ? <ResultView /> : null}
      <HelpOverlay />
      <Toaster
        theme="light"
        position="top-center"
        toastOptions={{ className: "bg-paper text-paper-fg border-rule" }}
      />
    </CardMount>
  );
}
