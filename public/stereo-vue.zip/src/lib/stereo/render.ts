function sampleDepth(
  depth: Float32Array,
  dw: number,
  dh: number,
  x: number,
  y: number,
  width: number,
  height: number,
) {
  const dx = ((x + 0.5) * dw) / width - 0.5;
  const dy = ((y + 0.5) * dh) / height - 0.5;
  const x0 = Math.min(dw - 1, Math.max(0, Math.floor(dx)));
  const y0 = Math.min(dh - 1, Math.max(0, Math.floor(dy)));
  const x1 = Math.min(dw - 1, x0 + 1);
  const y1 = Math.min(dh - 1, y0 + 1);
  const fx = dx - x0;
  const fy = dy - y0;
  const d00 = depth[y0 * dw + x0];
  const d10 = depth[y0 * dw + x1];
  const d01 = depth[y1 * dw + x0];
  const d11 = depth[y1 * dw + x1];
  return d00 * (1 - fx) * (1 - fy) + d10 * fx * (1 - fy) + d01 * (1 - fx) * fy + d11 * fx * fy;
}

function copyPixel(
  src: Uint8ClampedArray,
  dest: Uint8ClampedArray,
  si: number,
  di: number,
) {
  dest[di] = src[si];
  dest[di + 1] = src[si + 1];
  dest[di + 2] = src[si + 2];
  dest[di + 3] = 255;
}

/**
 * Depth-image-based rendering for one eye.
 * eye = +1 left (near objects shift right), -1 right.
 */
export function warpEye(
  src: ImageData,
  depth: Float32Array,
  dw: number,
  dh: number,
  eye: 1 | -1,
  strength: number,
  invert: boolean,
) {
  const { width, height, data } = src;
  const maxShift = Math.max(8, Math.round(width * 0.042 * strength));
  const out = new ImageData(width, height);
  const dest = out.data;
  const zbuf = new Float32Array(width * height);
  zbuf.fill(-1);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let d = sampleDepth(depth, dw, dh, x, y, width, height);
      if (invert) d = 1 - d;
      const destX = Math.round(x + eye * d * maxShift);
      if (destX < 0 || destX >= width) continue;
      const zi = y * width + destX;
      if (d >= zbuf[zi]) {
        zbuf[zi] = d;
        copyPixel(data, dest, (y * width + x) * 4, zi * 4);
      }
    }
  }

  for (let y = 0; y < height; y++) {
    const row = y * width;
    const fillDir = eye > 0 ? 1 : -1;
    for (let n = 0; n < 2; n++) {
      const start = n === 0 ? (fillDir > 0 ? 0 : width - 1) : fillDir > 0 ? width - 1 : 0;
      const end = n === 0 ? (fillDir > 0 ? width : -1) : fillDir > 0 ? -1 : width;
      const step = n === 0 ? fillDir : -fillDir;
      let last = -1;
      for (let x = start; x !== end; x += step) {
        const i = row + x;
        if (zbuf[i] >= 0) {
          last = x;
        } else if (last >= 0 && Math.abs(x - last) <= maxShift + 2) {
          copyPixel(dest, dest, (row + last) * 4, i * 4);
          zbuf[i] = zbuf[row + last];
        }
      }
    }
    for (let x = 0; x < width; x++) {
      const i = row + x;
      if (zbuf[i] < 0) copyPixel(data, dest, i * 4, i * 4);
    }
  }

  return out;
}

export function composeAnaglyph(left: ImageData, right: ImageData) {
  const { width, height } = left;
  const out = new ImageData(width, height);
  const L = left.data;
  const R = right.data;
  const D = out.data;
  for (let i = 0; i < D.length; i += 4) {
    D[i] = 0.299 * L[i] + 0.587 * L[i + 1] + 0.114 * L[i + 2];
    D[i + 1] = R[i + 1];
    D[i + 2] = R[i + 2];
    D[i + 3] = 255;
  }
  return out;
}

export function composeSbs(left: ImageData, right: ImageData) {
  const { width, height } = left;
  const out = new ImageData(width * 2, height);
  const D = out.data;
  const L = left.data;
  const R = right.data;
  for (let y = 0; y < height; y++) {
    const srcRow = y * width * 4;
    const destRow = y * width * 8;
    D.set(L.subarray(srcRow, srcRow + width * 4), destRow);
    D.set(R.subarray(srcRow, srcRow + width * 4), destRow + width * 4);
  }
  return out;
}

export type StereoOpts = {
  image: ImageData;
  depth: Float32Array;
  dw: number;
  dh: number;
  strength: number;
  invert: boolean;
};

export function downsampleImage(image: ImageData, maxEdge: number): ImageData {
  const scale = Math.min(1, maxEdge / Math.max(image.width, image.height));
  if (scale >= 0.995) return image;
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));
  const src = document.createElement("canvas");
  src.width = image.width;
  src.height = image.height;
  const sctx = src.getContext("2d");
  if (!sctx) throw new Error("Canvas is not available");
  sctx.putImageData(image, 0, 0);
  const dst = document.createElement("canvas");
  dst.width = width;
  dst.height = height;
  const dctx = dst.getContext("2d");
  if (!dctx) throw new Error("Canvas is not available");
  dctx.drawImage(src, 0, 0, width, height);
  return dctx.getImageData(0, 0, width, height);
}

export function liveWarpedPhoto(opts: StereoOpts, maxEdge = 480): ImageData {
  const small = downsampleImage(opts.image, maxEdge);
  return warpEye(small, opts.depth, opts.dw, opts.dh, 1, opts.strength, opts.invert);
}

export function renderStereoViews(opts: StereoOpts) {
  const left = warpEye(opts.image, opts.depth, opts.dw, opts.dh, 1, opts.strength, opts.invert);
  const right = warpEye(opts.image, opts.depth, opts.dw, opts.dh, -1, opts.strength, opts.invert);
  return { left, right };
}
