import { getSession, setSession, type SessionImage } from "./session";

export const MAX_PROCESS_EDGE = 1280;
export const DEPTH_EDGE = 384;

async function decodeToBitmap(blob: Blob): Promise<ImageBitmap> {
  try {
    return await createImageBitmap(blob, {
      imageOrientation: "from-image",
    } as ImageBitmapOptions);
  } catch {
    return await createImageBitmap(blob);
  }
}

export async function canvasFromBlob(blob: Blob, maxEdge = MAX_PROCESS_EDGE) {
  const bitmap = await decodeToBitmap(blob);
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas is not available");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  return canvas;
}

export function sessionFromCanvas(canvas: HTMLCanvasElement): SessionImage {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas is not available");
  const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const next = {
    canvas,
    data,
    width: canvas.width,
    height: canvas.height,
  };
  setSession(next);
  return next;
}

export function canvasToJpegUrl(canvas: HTMLCanvasElement, quality = 0.88) {
  return canvas.toDataURL("image/jpeg", quality);
}

export function imageDataToJpegUrl(image: ImageData, quality = 0.92) {
  const canvas = document.createElement("canvas");
  canvas.width = image.width;
  canvas.height = image.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is not available");
  ctx.putImageData(image, 0, 0);
  return canvas.toDataURL("image/jpeg", quality);
}

export async function imageDataToJpegBlob(image: ImageData, quality = 0.92) {
  const canvas = document.createElement("canvas");
  canvas.width = image.width;
  canvas.height = image.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is not available");
  ctx.putImageData(image, 0, 0);
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", quality),
  );
  if (!blob) throw new Error("Could not encode image");
  return blob;
}

export async function saveOrShare(
  blob: Blob,
  filename: string,
  mode: "auto" | "download" = "auto",
) {
  const file = new File([blob], filename, { type: blob.type || "image/jpeg" });
  const nav = navigator as Navigator & {
    canShare?: (data?: ShareData) => boolean;
  };
  if (mode === "auto" && typeof nav.share === "function" && nav.canShare?.({ files: [file] })) {
    try {
      await nav.share({ files: [file], title: "Stereo Vue" });
      return "shared" as const;
    } catch (error) {
      if ((error as DOMException).name === "AbortError") return "cancelled" as const;
    }
  }
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  return "downloaded" as const;
}

export function requireSession() {
  const current = getSession();
  if (!current) throw new Error("No photo loaded");
  return current;
}
